# Sessions Template

This should only be used once you are comfortable with creating an authentication and authorization system yourself.
This app is purely to save time on projects where writing out a login system becomes tedious.


