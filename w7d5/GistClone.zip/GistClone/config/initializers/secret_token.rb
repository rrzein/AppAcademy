# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SessionsTemplate::Application.config.secret_token = '0c7f252186f2ae69f4542119bf44357a756b922814d530dc2641648fba071c71580c59c9710698f657d1f5a3f9f1f18eb2aa287e9191158a7611d6accbe03320'
