class RootController < ApplicationController
end
