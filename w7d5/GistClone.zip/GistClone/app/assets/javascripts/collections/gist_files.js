SessionsTemplate.Collections.GistFiles = Backbone.Collection.extend({
  model: SessionsTemplate.Models.GistFile
});