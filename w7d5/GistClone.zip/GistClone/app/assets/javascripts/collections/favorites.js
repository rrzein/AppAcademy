SessionsTemplate.Collections.Favorites = Backbone.Collection.extend({
	model: SessionsTemplate.Models.Favorite,
})