SessionsTemplate.Collections.Gists = Backbone.Collection.extend({
  model: SessionsTemplate.Models.Gist,
  url: "/gists"
});
