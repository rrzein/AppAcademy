SessionsTemplate.Models.Favorite = Backbone.Model.extend({

});