SessionsTemplate.Models.GistFile = Backbone.Model.extend({

});