require 'test_helper'

class GistFileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
