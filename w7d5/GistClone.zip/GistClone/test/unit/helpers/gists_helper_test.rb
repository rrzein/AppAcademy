require 'test_helper'

class GistsHelperTest < ActionView::TestCase
end
