require 'test_helper'

class WizardTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
