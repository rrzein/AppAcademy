require 'test_helper'

class WandTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
