# Hogwarts School of Witchcraft and Wizardry

*NB: Run `bundle install` and `rake db:migrate` before you get
started.*

Welcome to the wizarding world. We have been tasked to develop an
application for Hogwarts that will allow them to keep track of
students, teachers, classes, houses, and wands for everybody at
Hogwarts and the other wizarding schools.

Your task today is to build the relationships between all of these
models. The database has already been setup and the models have been
annotated with their respective table schemas.

## Assignment

There will be no specs this time to guide you each step of the way;
use your magical mental powers to complete the assignment.

1. **Build all possible one-step relationships between all the models
(all possible `has_many`, `belongs_to`, and `has_one` associations).**
Use meaningful names for the associations wherever possible.

  For all associations that require any change from the default, (i.e.
  you have to specify class_name, foreign_key, or primary_key for the 
  association to work), please specify all 3 (class_name, foreign_key,
  and primary_key).
  

  Friendly notes:

  * There are exactly 14 one-step associations to be made.
  * A wizard and a wand are married one-to-one.
  * Note that the only table that contains people is 'wizards,'
  so anything that refers to a person will lead there.

2. **Additionally, build the following associations:**

  0. Student to Courses
  0. Instructors to Courses
  0. Student to Instructors
  0. Instructors to Students
  0. Student to House Master
  0. Wizard to Headmaster
  0. House to School
  0. Course to School

---

**NB: In total, there should be 22 associations in your models.**