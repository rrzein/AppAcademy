# == Schema Information
#
# Table name: houses
#
#  id         :integer          not null, primary key
#  name       :string(255)
#  building   :string(255)
#  master_id  :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class House < ActiveRecord::Base
  attr_accessible :building, :name, :master_id

  has_many :students,
  	:class_name => "Wizard",
  	:primary_key => :id,
  	:foreign_key => :house_id

  belongs_to :master,
  	:class_name => "Wizard",
  	:primary_key => :id
  	:foreign_key => :master_id

  # belongs_to :school,
  # 	:source => :students,
  # 	:through => :school

  
end
