# == Schema Information
#
# Table name: wizards
#
#  id         :integer          not null, primary key
#  fname      :string(255)
#  lname      :string(255)
#  house_id   :integer
#  school_id  :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Wizard < ActiveRecord::Base
  attr_accessible :fname, :lname, :house_id, :school_id

  has_one :wand,
  	:class_name => "Wand",
  	:primary_key => :id,
  	:foreign_key => :owner_id

  belongs_to :house,
  	:class_name => "House",
  	:primary_key => :id,
  	:foreign_key => :house_id

  belongs_to :school,
    :class_name => "School",
    :primary_key => :id,
    :foreign_key => :school_id
    
  # has_one :overseen_house,
  # 	:class_name => "House",
  # 	:primary_key => :id,
  # 	:foreign_key => :master_id



	# has_one :headed_school
	# 	:class_name => "School"
	# 	:primary_key => :id,
	# 	:foreign_key => :headmaster_id

	has_many :taught_courses
		:class_name => "Course",
		:primary_key => :id,
		:foreign_key => :instructor_id

	has_many :course_enrollments,
		:class_name => "CourseEnrollment"
		:primary_key => :id,
		:foreign_key => :student_id

	has_many :enrolled_courses,
		:through => :course_enrollments,
		:source => :course

	has_many :instructors
		:through => :enrolled_courses,
		:source => :instructor

	# has_many :students
	# 	:through => :courses,
	# 	:source => :enrolled_students

	has_one :house_master
		:through => :house,
		:source => :master

	has_one :headmaster,
		:through => :school,
		:source => :headmaster



end
