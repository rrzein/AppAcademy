# == Schema Information
#
# Table name: courses
#
#  id            :integer          not null, primary key
#  title         :string(255)
#  description   :string(255)
#  instructor_id :integer
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#

class Course < ActiveRecord::Base
  attr_accessible :description, :instructor_id, :title

  belongs_to :instructor,
  	:class_name => "Wizard",
  	:primary_key => :id,
  	:foreign_key => :instructor_id

  has_many :course_enrollments,
  	:class_name => "CourseEnrollment"
  	:primary_key => :id,
  	:foreign_key => :course_id

  has_many :enrolled_students,
  	:through => :course_enrollments
  	:source => :student

  # belongs_to :school,
  # 	:through => :enrolled_students,
  # 	:source => :school
end
