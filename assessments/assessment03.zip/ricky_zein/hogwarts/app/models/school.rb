# == Schema Information
#
# Table name: schools
#
#  id            :integer          not null, primary key
#  name          :string(255)
#  headmaster_id :integer
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#

class School < ActiveRecord::Base
  attr_accessible :headmaster_id, :name

  belongs_to :headmaster,
  	:class_name => "Wizard",
  	:primary_key => :id,
  	:foreign_key => :headmaster_id

  has_many :students,
  	:class_name => "Wizard",
  	:primary_key => :id,
  	:foreign_key => :school_id
end
