# == Schema Information
#
# Table name: wands
#
#  id              :integer          not null, primary key
#  core_ingredient :string(255)
#  owner_id        :integer
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#

class Wand < ActiveRecord::Base
  attr_accessible :core_ingredient, :owner_id

  belongs_to :owner,
  	:class_name => "Wizard",
  	:primary_key => :id
  	:foreign_key => :owner_id

end
