# Assessment 3

This assessment is in 2 parts.

**Total time: 1 hour 15 minutes**

## Part 1: SQL

`sql/` folder

Read `INSTRUCTIONS.md`

Recommended time: 25 minutes

## Part 2: Associations

`hogwarts/` folder

Read `README.md`

Recommended time: 50 minutes