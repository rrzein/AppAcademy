function Song() {
}

Song.prototype.play = function() {
  return 'Ladida...';
};

